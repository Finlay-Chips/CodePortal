//string
document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('Functions');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = 'https://docs.python.org/3.11/library/functions.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });
  // int
  document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('Types');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = 'https://docs.python.org/3.11/library/stdtypes.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });
  //double
  document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('Formats');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = ' https://docs.python.org/3.11/library/fileformats.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });
  //lang
  document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('DataTypes');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = 'https://docs.python.org/3.11/library/datatypes.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });
  //rect
  document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('Constants');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = 'https://docs.python.org/3.11/library/constants.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });

//Auto open
  document.addEventListener('DOMContentLoaded', function () {
    const iframe = document.getElementById('webPageFrame');
  
    
      iframe.src = 'https://docs.python.org/3.11/index.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
//Math
  document.addEventListener('DOMContentLoaded', function () {
    const loadButton = document.getElementById('Math');
    const iframe = document.getElementById('webPageFrame');
  
    loadButton.addEventListener('click', function () {
      iframe.src = 'https://docs.python.org/3.11/library/numeric.html'; // Replace with your desired URL
      iframe.style.display = 'block';
    });
  });

